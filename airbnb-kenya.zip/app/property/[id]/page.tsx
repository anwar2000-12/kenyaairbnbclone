"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { MapPin, Bed, Bath, Home, TrendingUp, DollarSign, Award } from "lucide-react"

// This would typically come from your API
const mockProperty = {
  id: 1,
  title: "Luxurious Apartment with Ocean View",
  location: "Nyali, Mombasa",
  price: 15000,
  image: "/placeholder.svg?height=400&width=600",
  bedrooms: 3,
  bathrooms: 2,
  size: 120,
  description: "A beautiful beachfront apartment with stunning ocean views...",
  amenities: ["Wi-Fi", "Air Conditioning", "Kitchen", "Free Parking", "Pool"],
  investmentScore: 9,
  rentalYield: "8.5%",
  propertyAppreciation: "5.2%",
}

export default function PropertyPage({ params }: { params: { id: string } }) {
  const [bookingDates, setBookingDates] = useState({ checkIn: "", checkOut: "" })
  const [totalPrice, setTotalPrice] = useState(0)

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setBookingDates((prev) => ({ ...prev, [name]: value }))

    if (bookingDates.checkIn && bookingDates.checkOut) {
      const nights =
        (new Date(bookingDates.checkOut).getTime() - new Date(bookingDates.checkIn).getTime()) / (1000 * 3600 * 24)
      const price = mockProperty.price * nights
      const serviceFee = price * 0.1 // 10% service fee
      setTotalPrice(price + serviceFee)
    }
  }

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the booking data to your API
    console.log("Booking:", { ...bookingDates, totalPrice })
    alert("Booking submitted! Total price: KES " + totalPrice.toLocaleString())
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Image
        src={mockProperty.image || "/placeholder.svg"}
        alt={mockProperty.title}
        width={600}
        height={400}
        className="w-full h-64 object-cover rounded-lg mb-4"
      />
      <h1 className="text-3xl font-bold mb-4">{mockProperty.title}</h1>
      <p className="text-gray-600 mb-4 flex items-center">
        <MapPin className="w-4 h-4 mr-1" /> {mockProperty.location}
      </p>
      <div className="flex justify-between items-center mb-4">
        <span className="flex items-center">
          <Bed className="w-4 h-4 mr-1" /> {mockProperty.bedrooms} bed(s)
        </span>
        <span className="flex items-center">
          <Bath className="w-4 h-4 mr-1" /> {mockProperty.bathrooms} bath(s)
        </span>
        <span className="flex items-center">
          <Home className="w-4 h-4 mr-1" /> {mockProperty.size} m²
        </span>
        <span className="text-kenya-red font-bold">KES {mockProperty.price.toLocaleString()} per night</span>
      </div>
      <div className="bg-gray-100 p-4 rounded-lg mb-6">
        <h2 className="text-xl font-semibold mb-2 flex items-center">
          <Award className="w-5 h-5 mr-2 text-kenya-red" /> Anwar's Note
        </h2>
        <p className="text-gray-700 italic">
          "I personally handpicked this property for its unique charm and excellent investment potential. The location
          is prime, and the amenities are top-notch. Whether you're staying for a few nights or considering a long-term
          investment, this property is sure to impress."
        </p>
        <p className="text-right text-gray-600 mt-2">- Anwar Burale</p>
      </div>
      <p className="mb-4">{mockProperty.description}</p>
      <div className="mb-4">
        <h2 className="text-xl font-semibold mb-2">Amenities</h2>
        <ul className="grid grid-cols-2 gap-2">
          {mockProperty.amenities.map((amenity) => (
            <li key={amenity} className="flex items-center">
              <span className="w-2 h-2 bg-kenya-green rounded-full mr-2"></span>
              {amenity}
            </li>
          ))}
        </ul>
      </div>
      <div className="bg-gray-100 p-4 rounded-lg mb-8">
        <h2 className="text-xl font-semibold mb-4">Investment Potential</h2>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <p className="text-sm text-gray-600">Investment Score</p>
            <p className="text-lg font-semibold flex items-center">
              <TrendingUp className="w-4 h-4 mr-1 text-kenya-green" /> {mockProperty.investmentScore}/10
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Rental Yield</p>
            <p className="text-lg font-semibold flex items-center">
              <DollarSign className="w-4 h-4 mr-1 text-kenya-green" /> {mockProperty.rentalYield}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Property Appreciation</p>
            <p className="text-lg font-semibold flex items-center">
              <TrendingUp className="w-4 h-4 mr-1 text-kenya-green" /> {mockProperty.propertyAppreciation}/year
            </p>
          </div>
        </div>
      </div>
      <form onSubmit={handleBooking} className="bg-gray-100 p-4 rounded-lg">
        <h2 className="text-xl font-semibold mb-4">Book this property</h2>
        <div className="flex gap-4 mb-4">
          <div className="flex-1">
            <label htmlFor="checkIn" className="block mb-1">
              Check-in
            </label>
            <input
              type="date"
              id="checkIn"
              name="checkIn"
              value={bookingDates.checkIn}
              onChange={handleDateChange}
              required
              className="w-full px-3 py-2 border rounded-md"
            />
          </div>
          <div className="flex-1">
            <label htmlFor="checkOut" className="block mb-1">
              Check-out
            </label>
            <input
              type="date"
              id="checkOut"
              name="checkOut"
              value={bookingDates.checkOut}
              onChange={handleDateChange}
              required
              className="w-full px-3 py-2 border rounded-md"
            />
          </div>
        </div>
        {totalPrice > 0 && (
          <div className="mb-4">
            <p>Total Price: KES {totalPrice.toLocaleString()}</p>
            <p className="text-sm text-gray-600">(Includes 10% service fee)</p>
          </div>
        )}
        <button type="submit" className="btn-kenya w-full">
          Book Now
        </button>
      </form>
    </div>
  )
}

