"use client"

import type React from "react"

import { useState } from "react"
import { Search } from "lucide-react"

export default function SearchBar() {
  const [location, setLocation] = useState("")

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Implement search functionality here
    console.log("Searching for:", location)
  }

  return (
    <form onSubmit={handleSearch} className="flex items-center justify-center">
      <input
        type="text"
        placeholder="Enter a location in Kenya"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
        className="w-full max-w-md px-4 py-2 rounded-l-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-kenya-red"
      />
      <button type="submit" className="btn-kenya rounded-l-none">
        <Search className="w-5 h-5" />
      </button>
    </form>
  )
}

