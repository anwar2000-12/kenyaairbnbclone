import PropertyCard from "./PropertyCard"

const properties = [
  {
    id: 1,
    title: "Modern Apartment with City View",
    location: "Westlands, Nairobi",
    price: 12000,
    image: "/placeholder.svg?height=200&width=300",
    bedrooms: 2,
    bathrooms: 2,
    size: 80,
    investmentScore: 8,
  },
  {
    id: 2,
    title: "Beachfront Villa",
    location: "Diani Beach, Kwale",
    price: 25000,
    image: "/placeholder.svg?height=200&width=300",
    bedrooms: 4,
    bathrooms: 3,
    size: 200,
    investmentScore: 9,
  },
  {
    id: 3,
    title: "Cozy Studio in City Center",
    location: "CBD, Nairobi",
    price: 8000,
    image: "/placeholder.svg?height=200&width=300",
    bedrooms: 1,
    bathrooms: 1,
    size: 40,
    investmentScore: 7,
  },
]

export default function PropertyList() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {properties.map((property) => (
        <PropertyCard key={property.id} {...property} />
      ))}
    </div>
  )
}

