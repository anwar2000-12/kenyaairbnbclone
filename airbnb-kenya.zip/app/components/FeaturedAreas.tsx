import Image from "next/image"
import Link from "next/link"

const featuredAreas = [
  { name: "Nairobi", image: "/placeholder.svg?height=200&width=300", averagePrice: 10000 },
  { name: "Mombasa", image: "/placeholder.svg?height=200&width=300", averagePrice: 8000 },
  { name: "Nakuru", image: "/placeholder.svg?height=200&width=300", averagePrice: 6000 },
  { name: "Kisumu", image: "/placeholder.svg?height=200&width=300", averagePrice: 7000 },
]

export default function FeaturedAreas() {
  return (
    <div className="mt-12">
      <h2 className="text-2xl font-semibold mb-4">Featured Areas</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {featuredAreas.map((area) => (
          <Link href={`/search?location=${area.name}`} key={area.name} className="group">
            <div className="relative overflow-hidden rounded-lg shadow-md">
              <Image
                src={area.image || "/placeholder.svg"}
                alt={area.name}
                width={300}
                height={200}
                className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-4">
                <h3 className="text-lg font-semibold">{area.name}</h3>
                <p className="text-sm">Avg. KES {area.averagePrice.toLocaleString()} / night</p>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}

