import AccommodationCard from "./AccommodationCard"

const accommodations = [
  {
    id: 1,
    name: "Beachfront Villa",
    location: "Diani Beach",
    price: 150,
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 2,
    name: "Safari Lodge",
    location: "Maasai Mara",
    price: 200,
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 3,
    name: "City Apartment",
    location: "Nairobi",
    price: 80,
    image: "/placeholder.svg?height=200&width=300",
  },
]

export default function AccommodationList() {
  return (
    <div className="space-y-6">
      {accommodations.map((accommodation) => (
        <AccommodationCard key={accommodation.id} {...accommodation} />
      ))}
    </div>
  )
}

