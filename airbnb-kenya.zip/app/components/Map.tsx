export default function Map() {
  return (
    <div className="bg-gray-200 rounded-lg overflow-hidden h-96">
      {/* Implement map component here */}
      <p className="text-center p-4">Map of Kenya will be displayed here</p>
    </div>
  )
}

