import Image from "next/image"
import Link from "next/link"
import { Home, MapPin, Bed, Bath, TrendingUp, Award } from "lucide-react"

interface PropertyCardProps {
  id: number
  title: string
  location: string
  price: number
  image: string
  bedrooms: number
  bathrooms: number
  size: number
  investmentScore: number
}

export default function PropertyCard({
  id,
  title,
  location,
  price,
  image,
  bedrooms,
  bathrooms,
  size,
  investmentScore,
}: PropertyCardProps) {
  return (
    <Link href={`/property/${id}`} className="block">
      <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
        <div className="relative">
          <Image
            src={image || "/placeholder.svg"}
            alt={title}
            width={300}
            height={200}
            className="w-full h-48 object-cover"
          />
          <div className="absolute top-2 right-2 bg-kenya-red text-white px-2 py-1 rounded-full text-sm font-semibold">
            {investmentScore}/10
          </div>
        </div>
        <div className="p-4">
          <h2 className="text-xl font-semibold mb-2">{title}</h2>
          <p className="text-gray-600 mb-2 flex items-center">
            <MapPin className="w-4 h-4 mr-1" /> {location}
          </p>
          <div className="flex justify-between items-center mb-2">
            <span className="flex items-center">
              <Bed className="w-4 h-4 mr-1" /> {bedrooms} bed(s)
            </span>
            <span className="flex items-center">
              <Bath className="w-4 h-4 mr-1" /> {bathrooms} bath(s)
            </span>
            <span className="flex items-center">
              <Home className="w-4 h-4 mr-1" /> {size} m²
            </span>
          </div>
          <div className="flex justify-between items-center">
            <p className="text-kenya-red font-bold">KES {price.toLocaleString()} / night</p>
            <span className="flex items-center text-kenya-green">
              <TrendingUp className="w-4 h-4 mr-1" /> Good investment
            </span>
          </div>
          <p className="text-sm text-gray-500 mt-2 flex items-center">
            <Award className="w-4 h-4 mr-1" /> Anwar's Curated Selection
          </p>
        </div>
      </div>
    </Link>
  )
}

