import Image from "next/image"
import Link from "next/link"
import { MapPin, Bed, Bath } from "lucide-react"

interface AccommodationCardProps {
  id: number
  title: string
  location: string
  price: number
  image: string
  bedrooms: number
  bathrooms: number
}

export default function AccommodationCard({
  id,
  title,
  location,
  price,
  image,
  bedrooms,
  bathrooms,
}: AccommodationCardProps) {
  return (
    <Link href={`/listing/${id}`} className="block">
      <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
        <Image
          src={image || "/placeholder.svg"}
          alt={title}
          width={300}
          height={200}
          className="w-full h-48 object-cover"
        />
        <div className="p-4">
          <h2 className="text-xl font-semibold mb-2">{title}</h2>
          <p className="text-gray-600 mb-2 flex items-center">
            <MapPin className="w-4 h-4 mr-1" /> {location}
          </p>
          <div className="flex justify-between items-center mb-2">
            <span className="flex items-center">
              <Bed className="w-4 h-4 mr-1" /> {bedrooms} bed(s)
            </span>
            <span className="flex items-center">
              <Bath className="w-4 h-4 mr-1" /> {bathrooms} bath(s)
            </span>
          </div>
          <p className="text-kenya-red font-bold">KES {price.toLocaleString()} per night</p>
        </div>
      </div>
    </Link>
  )
}

