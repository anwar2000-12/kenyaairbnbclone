"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { User, LogIn, LogOut, Home, Search } from "lucide-react"

export default function Header() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [userName, setUserName] = useState("")
  const router = useRouter()

  useEffect(() => {
    const verifyToken = async () => {
      const token = localStorage.getItem("token")
      if (token) {
        try {
          const response = await fetch("/api/auth/verify", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ token }),
          })
          if (response.ok) {
            const data = await response.json()
            setIsLoggedIn(true)
            setUserName(data.email.split("@")[0])
          } else {
            handleLogout()
          }
        } catch (error) {
          console.error("Error verifying token:", error)
          handleLogout()
        }
      }
    }

    verifyToken()
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("token")
    setIsLoggedIn(false)
    setUserName("")
    router.push("/")
  }

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="flex items-center">
          <span className="text-2xl font-bold text-kenya-red">BuraleStays</span>
          <span className="text-sm text-gray-600 ml-2">by Anwar Burale</span>
        </Link>
        <div className="flex items-center space-x-4">
          <Link href="/search" className="text-gray-600 hover:text-kenya-green flex items-center">
            <Search className="w-4 h-4 mr-1" /> Explore
          </Link>
          <Link href="/host" className="text-gray-600 hover:text-kenya-green flex items-center">
            <Home className="w-4 h-4 mr-1" /> Become a Host
          </Link>
          {isLoggedIn ? (
            <>
              <Link href="/profile" className="text-gray-600 hover:text-kenya-green flex items-center">
                <User className="w-4 h-4 mr-1" /> {userName}
              </Link>
              <button onClick={handleLogout} className="flex items-center text-gray-600 hover:text-kenya-green">
                <LogOut className="w-4 h-4 mr-1" /> Logout
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="text-gray-600 hover:text-kenya-green flex items-center">
                <LogIn className="w-4 h-4 mr-1" /> Login
              </Link>
              <Link href="/signup" className="text-gray-600 hover:text-kenya-green flex items-center">
                <User className="w-4 h-4 mr-1" /> Sign Up
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  )
}

