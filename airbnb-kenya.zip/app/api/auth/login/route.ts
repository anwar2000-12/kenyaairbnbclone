import { NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"

// In a real application, you would use a database
const users: any[] = []

export async function POST(request: Request) {
  const { email, password } = await request.json()

  // Find user
  const user = users.find((user) => user.email === email)
  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 400 })
  }

  // Check password
  const isPasswordValid = await bcrypt.compare(password, user.password)
  if (!isPasswordValid) {
    return NextResponse.json({ error: "Invalid password" }, { status: 400 })
  }

  // Generate JWT
  const token = jwt.sign({ userId: user.id, email: user.email }, process.env.JWT_SECRET!, { expiresIn: "1d" })

  return NextResponse.json({ token, user: { id: user.id, name: user.name, email: user.email } })
}

