import { NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"

// In a real application, you would use a database
const users: any[] = []

export async function POST(request: Request) {
  const { name, email, password } = await request.json()

  // Check if user already exists
  if (users.find((user) => user.email === email)) {
    return NextResponse.json({ error: "User already exists" }, { status: 400 })
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 10)

  // Create new user
  const newUser = { id: users.length + 1, name, email, password: hashedPassword }
  users.push(newUser)

  // Generate JWT
  const token = jwt.sign({ userId: newUser.id, email: newUser.email }, process.env.JWT_SECRET!, { expiresIn: "1d" })

  return NextResponse.json({ token, user: { id: newUser.id, name: newUser.name, email: newUser.email } })
}

