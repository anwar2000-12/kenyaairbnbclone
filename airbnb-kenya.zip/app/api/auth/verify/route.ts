import { NextResponse } from "next/server"
import jwt from "jsonwebtoken"

export async function POST(request: Request) {
  const { token } = await request.json()

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as { userId: number; email: string }
    return NextResponse.json({ userId: decoded.userId, email: decoded.email })
  } catch (error) {
    return NextResponse.json({ error: "Invalid token" }, { status: 401 })
  }
}

