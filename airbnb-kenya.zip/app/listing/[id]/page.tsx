"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { MapPin, Bed, Bath } from "lucide-react"

// This would typically come from your API
const mockListing = {
  id: 1,
  title: "Luxurious Villa in Diani",
  location: "Diani Beach, Kwale County",
  price: 15000,
  image: "/placeholder.svg?height=400&width=600",
  bedrooms: 3,
  bathrooms: 2,
  description: "A beautiful beachfront villa with stunning ocean views...",
}

export default function ListingPage({ params }: { params: { id: string } }) {
  const [bookingDates, setBookingDates] = useState({ checkIn: "", checkOut: "" })
  const [totalPrice, setTotalPrice] = useState(0)

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setBookingDates((prev) => ({ ...prev, [name]: value }))

    if (bookingDates.checkIn && bookingDates.checkOut) {
      const nights =
        (new Date(bookingDates.checkOut).getTime() - new Date(bookingDates.checkIn).getTime()) / (1000 * 3600 * 24)
      const price = mockListing.price * nights
      const serviceFee = price * 0.1 // 10% service fee
      setTotalPrice(price + serviceFee)
    }
  }

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the booking data to your API
    console.log("Booking:", { ...bookingDates, totalPrice })
    alert("Booking submitted! Total price: KES " + totalPrice.toLocaleString())
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Image
        src={mockListing.image || "/placeholder.svg"}
        alt={mockListing.title}
        width={600}
        height={400}
        className="w-full h-64 object-cover rounded-lg mb-4"
      />
      <h1 className="text-3xl font-bold mb-4">{mockListing.title}</h1>
      <p className="text-gray-600 mb-4 flex items-center">
        <MapPin className="w-4 h-4 mr-1" /> {mockListing.location}
      </p>
      <div className="flex justify-between items-center mb-4">
        <span className="flex items-center">
          <Bed className="w-4 h-4 mr-1" /> {mockListing.bedrooms} bed(s)
        </span>
        <span className="flex items-center">
          <Bath className="w-4 h-4 mr-1" /> {mockListing.bathrooms} bath(s)
        </span>
        <span className="text-kenya-red font-bold">KES {mockListing.price.toLocaleString()} per night</span>
      </div>
      <p className="mb-8">{mockListing.description}</p>
      <form onSubmit={handleBooking} className="bg-gray-100 p-4 rounded-lg">
        <h2 className="text-xl font-semibold mb-4">Book this property</h2>
        <div className="flex gap-4 mb-4">
          <div className="flex-1">
            <label htmlFor="checkIn" className="block mb-1">
              Check-in
            </label>
            <input
              type="date"
              id="checkIn"
              name="checkIn"
              value={bookingDates.checkIn}
              onChange={handleDateChange}
              required
              className="w-full px-3 py-2 border rounded-md"
            />
          </div>
          <div className="flex-1">
            <label htmlFor="checkOut" className="block mb-1">
              Check-out
            </label>
            <input
              type="date"
              id="checkOut"
              name="checkOut"
              value={bookingDates.checkOut}
              onChange={handleDateChange}
              required
              className="w-full px-3 py-2 border rounded-md"
            />
          </div>
        </div>
        {totalPrice > 0 && (
          <div className="mb-4">
            <p>Total Price: KES {totalPrice.toLocaleString()}</p>
            <p className="text-sm text-gray-600">(Includes 10% service fee)</p>
          </div>
        )}
        <button type="submit" className="btn-kenya w-full">
          Book Now
        </button>
      </form>
    </div>
  )
}

