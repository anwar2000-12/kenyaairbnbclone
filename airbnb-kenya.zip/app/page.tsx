import SearchBar from "./components/SearchBar"
import PropertyList from "./components/PropertyList"
import FeaturedAreas from "./components/FeaturedAreas"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-4 text-center text-kenya-red">Welcome to BuraleStays</h1>
      <p className="text-center text-gray-600 mb-8">Discover Kenya's Finest Properties, curated by Anwar Burale</p>
      <SearchBar />
      <div className="my-12 p-6 bg-gray-100 rounded-lg">
        <h2 className="text-2xl font-semibold mb-4">A Message from Anwar Burale</h2>
        <p className="text-gray-700">
          "Welcome to BuraleStays, where we bring you the best of Kenyan hospitality and real estate. Whether you're
          looking for a short-term stay or considering a property investment, we're here to guide you through the
          vibrant landscape of Kenya's real estate market. Enjoy your stay and discover the potential of our beautiful
          country!"
        </p>
      </div>
      <FeaturedAreas />
      <div className="mt-12">
        <h2 className="text-2xl font-semibold mb-4">Top-Rated Stays</h2>
        <PropertyList />
      </div>
    </div>
  )
}

